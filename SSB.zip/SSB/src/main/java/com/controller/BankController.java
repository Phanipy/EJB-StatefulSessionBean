package com.controller;

import javax.faces.bean.ManagedBean;

import com.model.Bank;
import com.model.BankRemote;

@ManagedBean(name="bc",eager=true)
public class BankController {
	int w;
	int d;
	int bal;

	//BankRemote bankremote;
	Bank bankremote=new Bank();
	
	public int getW() {
		return w;
	}
	public void setW(int w) {
		this.w = w;
	}
	public int getD() {
		return d;
	}
	public void setD(int d) {
		this.d = d;
	}
	public int getBal() {
		return bal;
	}
	public void setBal(int bal) {
		this.bal = bal;
	}

	public void callWithdraw()
	{
		bankremote.withdraw(w);
		bal=bankremote.getBalance();
	}
	public void callDeposit()
	{
		bankremote.deposit(d);
		bal=bankremote.getBalance();
	}
}

